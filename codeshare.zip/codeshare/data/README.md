# Data Files

This directory is intentionally empty. Do not commit raw OULAD files or
locally generated student-level feature files unless redistribution is
permitted by the applicable data licence and ethics requirements.

For an experiment, provide the feature and label CSV files described in the
top-level `README.md` and point `x-csv` and `y-csv` in `pyproject.toml` to
their locations.
