from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import accuracy_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset


class ResidualBlock(nn.Module):
    def __init__(self, dim: int, hidden_dim: int, dropout: float = 0.3):
        super().__init__()
        self.fc1 = nn.Linear(dim, hidden_dim)
        self.norm1 = nn.LayerNorm(hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, dim)
        self.norm2 = nn.LayerNorm(dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        out = self.fc1(x)
        out = self.norm1(out)
        out = self.relu(out)
        out = self.dropout(out)
        out = self.fc2(out)
        out = self.norm2(out)
        out = self.dropout(out)
        out = out + identity
        return self.relu(out)


class NeuralNetwork(nn.Module):
    """ResNet-style model for tabular features."""

    def __init__(
        self,
        in_dim: int,
        out_dim: int,
        width: int = 64,
        hidden_dim: int = 128,
        num_blocks: int = 32,
        dropout: float = 0.3,
    ):
        super().__init__()
        self.stem = nn.Linear(in_dim, width)
        self.stem_norm = nn.LayerNorm(width)
        self.relu = nn.ReLU()
        self.blocks = nn.Sequential(
            *[ResidualBlock(width, hidden_dim, dropout=dropout) for _ in range(num_blocks)]
        )
        self.head = nn.Linear(width, out_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        x = self.stem_norm(x)
        x = self.relu(x)
        x = self.blocks(x)
        return self.head(x)


def get_weights(model: nn.Module) -> List[np.ndarray]:
    return [v.detach().cpu().numpy() for _, v in model.state_dict().items()]


def set_weights(model: nn.Module, parameters: List[np.ndarray]) -> None:
    state_dict = model.state_dict()
    keys = list(state_dict.keys())
    for k, p in zip(keys, parameters):
        state_dict[k] = torch.tensor(p)
    model.load_state_dict(state_dict, strict=True)


def make_dataloader(
    X: np.ndarray,
    y: np.ndarray,
    batch_size: int,
    shuffle: bool,
    seed: int | None = None,
) -> DataLoader:
    xt = torch.tensor(X, dtype=torch.float32)
    yt = torch.tensor(y, dtype=torch.long)
    ds = TensorDataset(xt, yt)
    generator = None
    if seed is not None:
        generator = torch.Generator()
        generator.manual_seed(seed)
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, generator=generator)


@dataclass
class PreparedData:
    partitions: List[Tuple[np.ndarray, np.ndarray]]
    input_dim: int
    num_classes: int


_CACHE: Dict[str, PreparedData] = {}


def _cache_key(x_csv: str, y_csv: str, num_clients: int, seed: int) -> str:
    return f"{Path(x_csv).resolve()}::{Path(y_csv).resolve()}::{num_clients}::{seed}"


def split_into_clients_numpy(
    X: np.ndarray,
    y: np.ndarray,
    n_clients: int,
    region_dummy: bool,
    seed: int = 42,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    n_samples = len(X)
    assert n_samples == len(y), "Number of samples in X and y must be the same."
    assert n_clients > 0, "Number of clients must be greater than 0."
    assert n_clients <= n_samples, "Number of clients cannot be greater than number of samples."

    np.random.seed(seed)
    clients_indices: List[np.ndarray] = []

    if region_dummy:
        if X.shape[1] <= 50:
            raise ValueError(
                "partition-mode='region_dummy' requires at least 51 feature columns "
                "because it uses X[:, 38:51] for region dummies."
            )
        for col_idx in range(38, 51):
            column = X[:, col_idx]
            clients_indices.append(np.where(column > 0)[0])
        if n_clients != len(clients_indices):
            raise ValueError(
                "partition-mode='region_dummy' creates 13 clients from columns 38..50. "
                f"Set num-clients=13 (current: {n_clients})."
            )
    else:
        random_indices = np.random.choice(n_samples, n_samples, replace=False)
        clients_indices = [np.asarray(idx) for idx in np.array_split(random_indices, n_clients)]

    clients: List[Tuple[np.ndarray, np.ndarray]] = []
    for client_indices in clients_indices:
        X_client = X[client_indices].copy()
        y_client = y[client_indices]
        clients.append((X_client, y_client))
    return clients


def load_oulad_partitions(
    x_csv: str,
    y_csv: str,
    num_clients: int,
    seed: int,
    partition_mode: str,
) -> PreparedData:
    key = f"{_cache_key(x_csv, y_csv, num_clients, seed)}::{partition_mode}"
    if key in _CACHE:
        return _CACHE[key]

    X_df = pd.read_csv(x_csv)
    y = pd.read_csv(y_csv).to_numpy().ravel()

    X = X_df.to_numpy()
    scaler = StandardScaler()
    X = scaler.fit_transform(X)

    # All samples are assigned to clients; evaluation happens via each client's local eval split.
    if partition_mode == "iid":
        partitions = split_into_clients_numpy(
            X, y, n_clients=num_clients, region_dummy=False, seed=seed
        )
    elif partition_mode == "region_dummy":
        partitions = split_into_clients_numpy(
            X, y, n_clients=num_clients, region_dummy=True, seed=seed
        )
    else:
        raise ValueError("partition-mode must be either 'iid' or 'region_dummy'")

    prepared = PreparedData(
        partitions=partitions,
        input_dim=X.shape[1],
        num_classes=int(len(np.unique(y))),
    )
    _CACHE[key] = prepared
    return prepared


def split_partition_train_eval(
    X: np.ndarray,
    y: np.ndarray,
    eval_size: float,
    seed: int,
    partition_id: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    if not (0.0 < eval_size < 1.0):
        raise ValueError("client-eval-size must be in (0, 1)")
    split_seed = seed + partition_id
    try:
        return train_test_split(
            X,
            y,
            test_size=eval_size,
            random_state=split_seed,
            stratify=y,
        )
    except ValueError:
        return train_test_split(
            X,
            y,
            test_size=eval_size,
            random_state=split_seed,
            stratify=None,
        )


def train_one_client(model: nn.Module, loader: DataLoader, epochs: int, lr: float, device: torch.device) -> float:
    model.to(device)
    model.train()
    criterion = nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    running = 0.0
    for _ in range(epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()
            running += float(loss.item())

    return running / max(1, epochs * len(loader))


def train_one_client_with_prox(
    model: nn.Module,
    loader: DataLoader,
    epochs: int,
    lr: float,
    device: torch.device,
    proximal_mu: float,
) -> float:
    if proximal_mu <= 0.0:
        return train_one_client(model, loader, epochs, lr, device)

    model.to(device)
    model.train()
    criterion = nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    global_params = [p.detach().clone().to(device) for p in model.parameters()]

    running = 0.0
    for _ in range(epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            optimizer.zero_grad()
            logits = model(xb)
            base_loss = criterion(logits, yb)
            prox_term = 0.0
            for p, g in zip(model.parameters(), global_params):
                prox_term += torch.sum((p - g) ** 2)
            loss = base_loss + 0.5 * proximal_mu * prox_term
            loss.backward()
            optimizer.step()
            running += float(loss.item())

    return running / max(1, epochs * len(loader))


@torch.no_grad()
def eval_model(model: nn.Module, loader: DataLoader, device: torch.device) -> Dict[str, float]:
    model.to(device)
    model.eval()
    criterion = nn.CrossEntropyLoss().to(device)

    losses = 0.0
    preds_all: List[int] = []
    labels_all: List[int] = []

    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        logits = model(xb)
        losses += float(criterion(logits, yb).item())
        preds = logits.argmax(dim=1)
        preds_all.extend(preds.cpu().numpy().tolist())
        labels_all.extend(yb.cpu().numpy().tolist())

    loss = losses / max(1, len(loader))
    acc = accuracy_score(labels_all, preds_all)
    f1 = f1_score(labels_all, preds_all, average="macro")

    return {"loss": float(loss), "acc": float(acc), "f1": float(f1)}
