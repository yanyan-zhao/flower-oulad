from __future__ import annotations

import csv
import inspect
from datetime import datetime
from pathlib import Path
from typing import Any, List

import torch
from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord, RecordDict
from flwr.serverapp import Grid, ServerApp
from flwr.serverapp import strategy as fl_strat

from oulad_flower.task import (
    NeuralNetwork,
    load_oulad_partitions,
)


app = ServerApp()


def _set_torch_seed(seed: int) -> None:
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def train_metrics_aggr_fn(records: List[RecordDict], weighting_metric_name: str) -> MetricRecord:
    del weighting_metric_name
    total = 0
    loss_sum = 0.0
    train_total = 0
    for record in records:
        metrics = MetricRecord(record["metrics"])
        n = int(metrics["num-examples"])
        total += n
        loss_sum += n * float(metrics["train_loss"])
        train_total += int(metrics.get("train-num-examples", n))

    if total == 0:
        return MetricRecord({"train_loss": float("nan"), "train-num-examples": 0})

    return MetricRecord(
        {
            "train_loss": loss_sum / total,
            "train-num-examples": train_total,
        }
    )


def evaluate_metrics_aggr_fn(records: List[RecordDict], weighting_metric_name: str) -> MetricRecord:
    del weighting_metric_name
    total = 0
    loss_sum = 0.0
    acc_sum = 0.0
    f1_sum = 0.0
    eval_total = 0

    for record in records:
        metrics = MetricRecord(record["metrics"])
        n = int(metrics["num-examples"])
        total += n
        loss_sum += n * float(metrics["loss"])
        acc_sum += n * float(metrics["acc"])
        f1_sum += n * float(metrics["f1"])
        eval_total += int(metrics.get("eval-num-examples", n))

    if total == 0:
        return MetricRecord(
            {
                "loss": float("nan"),
                "acc": float("nan"),
                "f1": float("nan"),
                "eval-num-examples": 0,
            }
        )

    return MetricRecord(
        {
            "loss": loss_sum / total,
            "acc": acc_sum / total,
            "f1": f1_sum / total,
            "eval-num-examples": eval_total,
        }
    )


def _last_metric_from_round_dict(
    metrics_by_round: dict[int, MetricRecord], metric_name: str
) -> float | None:
    if not metrics_by_round:
        return None
    last_round = max(metrics_by_round.keys())
    metric_record = metrics_by_round[last_round]
    if metric_name not in metric_record:
        return None
    return float(metric_record[metric_name])


def _metric_curve_from_round_dict(
    metrics_by_round: dict[int, MetricRecord], metric_name: str
) -> list[tuple[int, float]]:
    curve: list[tuple[int, float]] = []
    for round_id in sorted(metrics_by_round.keys()):
        metric_record = metrics_by_round[round_id]
        if metric_name in metric_record:
            curve.append((round_id, float(metric_record[metric_name])))
    return curve


def _mean_metric_from_round_range(
    metrics_by_round: dict[int, MetricRecord],
    metric_name: str,
    start_round: int,
    end_round: int,
) -> float | None:
    values: list[float] = []
    for round_id in sorted(metrics_by_round.keys()):
        if round_id < start_round or round_id > end_round:
            continue
        metric_record = metrics_by_round[round_id]
        if metric_name in metric_record:
            values.append(float(metric_record[metric_name]))
    if not values:
        return None
    return sum(values) / len(values)


def _sum_metric_from_record_dict(
    metrics_by_round: dict[int, MetricRecord], metric_name: str
) -> int:
    total = 0
    for metric_record in metrics_by_round.values():
        if metric_name in metric_record:
            total += int(metric_record[metric_name])
    return total


def _max_metric_from_round_dict(
    metrics_by_round: dict[int, MetricRecord], metric_name: str
) -> tuple[float | None, int | None]:
    best_value: float | None = None
    best_round: int | None = None
    for round_id, metric_record in metrics_by_round.items():
        if metric_name not in metric_record:
            continue
        value = float(metric_record[metric_name])
        if best_value is None or value > best_value:
            best_value = value
            best_round = round_id
    return best_value, best_round


def _min_metric_from_round_dict(
    metrics_by_round: dict[int, MetricRecord], metric_name: str
) -> tuple[float | None, int | None]:
    best_value: float | None = None
    best_round: int | None = None
    for round_id, metric_record in metrics_by_round.items():
        if metric_name not in metric_record:
            continue
        value = float(metric_record[metric_name])
        if best_value is None or value < best_value:
            best_value = value
            best_round = round_id
    return best_value, best_round


def _make_strategy(strategy_name: str, num_clients: int, context: Context):
    del num_clients
    base_kwargs = {
        # Keep custom metric aggregation so round logs/CSV preserve real sample totals.
        "train_metrics_aggr_fn": train_metrics_aggr_fn,
        "evaluate_metrics_aggr_fn": evaluate_metrics_aggr_fn,
        "eval_metrics_aggr_fn": evaluate_metrics_aggr_fn,
    }
    name = strategy_name.lower()
    class_map = {
        "fedavg": "FedAvg",
        "fedavgm": "FedAvgM",
        "fedadagrad": "FedAdagrad",
        "fedadam": "FedAdam",
        "fedprox": "FedProx",
        "fedyogi": "FedYogi",
        "fedmedian": "FedMedian",
        "fedtrimmedavg": "FedTrimmedAvg",
        "qfedavg": "QFedAvg",
    }
    if name not in class_map:
        raise ValueError(
            "strategy must be one of: fedavg, fedavgm, fedadagrad, fedadam, fedprox, "
            "fedyogi, fedmedian, fedtrimmedavg, qfedavg"
        )

    class_name = class_map[name]
    strategy_cls = getattr(fl_strat, class_name, None)
    if strategy_cls is None:
        raise ValueError(
            f"Strategy '{class_name}' is not available in your installed Flower version."
        )

    kwargs = dict(base_kwargs)
    sig = inspect.signature(strategy_cls.__init__)
    params = sig.parameters
    if name == "fedavgm" and "server_momentum" in params:
        kwargs["server_momentum"] = float(context.run_config["fedavgm-server-momentum"])
    if name == "fedadam":
        if "eta" in params:
            kwargs["eta"] = float(context.run_config["fedadam-eta"])
        if "eta_l" in params:
            kwargs["eta_l"] = float(context.run_config["fedadam-eta-l"])
    if name == "fedyogi":
        if "eta" in params:
            kwargs["eta"] = float(context.run_config["fedyogi-eta"])
        if "eta_l" in params:
            kwargs["eta_l"] = float(context.run_config["fedyogi-eta-l"])
    if name == "qfedavg":
        q_val = float(context.run_config["qfed-q"])
        client_lr = float(context.run_config["qfed-client-learning-rate"])
        if (
            "client_learning_rate" in params
            and params["client_learning_rate"].default is inspect._empty
        ):
            kwargs["client_learning_rate"] = client_lr
        if "q" in params and params["q"].default is inspect._empty:
            kwargs["q"] = q_val
        elif "q_param" in params and params["q_param"].default is inspect._empty:
            kwargs["q_param"] = q_val
    if name == "fedprox" and "proximal_mu" in params:
        kwargs["proximal_mu"] = float(context.run_config["proximal-mu"])
    if name == "fedtrimmedavg":
        beta_val = float(context.run_config["trimmed-beta"])
        if "beta" in params and params["beta"].default is inspect._empty:
            kwargs["beta"] = beta_val
        elif (
            "trimmed_avg_beta" in params
            and params["trimmed_avg_beta"].default is inspect._empty
        ):
            kwargs["trimmed_avg_beta"] = beta_val

    accepted = set(params.keys())
    accepted.discard("self")
    filtered_kwargs = {k: v for k, v in kwargs.items() if k in accepted}
    return strategy_cls(**filtered_kwargs)


def _safe_slug(value: Any) -> str:
    text = str(value).strip().lower()
    allowed: list[str] = []
    for char in text:
        if char.isalnum() or char in {"-", "_", "."}:
            allowed.append(char)
        elif char in {",", " ", "=", ":", ";", "/"}:
            allowed.append("-")
    slug = "".join(allowed).strip("-._")
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug or "na"


def _strategy_slug(strategies: list[str]) -> str:
    short_names = {
        "fedavg": "avg",
        "fedavgm": "avgm",
        "fedprox": "prox",
        "fedadagrad": "adagrad",
        "fedadam": "adam",
        "fedyogi": "yogi",
        "fedmedian": "median",
        "fedtrimmedavg": "trim",
        "qfedavg": "qavg",
    }
    return "-".join(short_names.get(name, _safe_slug(name)) for name in strategies)


def _run_config_slug(context: Context, strategies: list[str]) -> str:
    parts = [
        f"s-{_strategy_slug(strategies)}",
        f"r-{_safe_slug(context.run_config['num-server-rounds'])}",
        f"lr-{_safe_slug(context.run_config['learning-rate'])}",
        f"ep-{_safe_slug(context.run_config['local-epochs'])}",
        f"bs-{_safe_slug(context.run_config['batch-size'])}",
        f"seed-{_safe_slug(context.run_config['seed'])}",
        f"ts-{_safe_slug(context.run_config['torch-seed'])}",
        f"ds-{_safe_slug(context.run_config['dataloader-seed'])}",
        f"part-{_safe_slug(context.run_config['partition-mode'])}",
        f"c-{_safe_slug(context.run_config['num-clients'])}",
    ]
    if "fedprox" in strategies:
        parts.append(f"mu-{_safe_slug(context.run_config['proximal-mu'])}")
    if "fedavgm" in strategies:
        parts.append(f"mom-{_safe_slug(context.run_config['fedavgm-server-momentum'])}")
    if "fedadam" in strategies:
        parts.append(f"aeta-{_safe_slug(context.run_config['fedadam-eta'])}")
        parts.append(f"aetal-{_safe_slug(context.run_config['fedadam-eta-l'])}")
    if "fedyogi" in strategies:
        parts.append(f"yeta-{_safe_slug(context.run_config['fedyogi-eta'])}")
        parts.append(f"yetal-{_safe_slug(context.run_config['fedyogi-eta-l'])}")
    if "fedtrimmedavg" in strategies:
        parts.append(f"trim-{_safe_slug(context.run_config['trimmed-beta'])}")
    if "qfedavg" in strategies:
        parts.append(f"q-{_safe_slug(context.run_config['qfed-q'])}")
    return "__".join(parts)


def _parse_compare_strategies(raw: str) -> list[str]:
    values = [v.strip().lower() for v in raw.split(",") if v.strip()]
    # Preserve input order while removing duplicates.
    return list(dict.fromkeys(values))


def _as_bool(value: Any, default: bool = True) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    return default


def _export_comparison_csv(
    out_dir: Path,
    strategies: list[str],
    all_results: dict[str, dict[str, Any]],
) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = out_dir / "comparison.csv"
    fields = [
        "strategy",
        "selected_split_seed",
        "last_train_loss",
        "best_train_loss",
        "best_train_loss_round",
        "client_last_eval_loss",
        "client_best_eval_loss",
        "client_best_eval_loss_round",
        "client_last_acc",
        "client_best_acc",
        "client_best_acc_round",
        "client_mean_acc_30_50",
        "client_last_f1",
        "client_best_f1",
        "client_best_f1_round",
        "client_mean_f1_30_50",
        "client_train_num_examples_total",
        "client_eval_num_examples_total",
        "recommended_final_acc",
        "recommended_final_f1",
    ]
    with csv_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for name in strategies:
            m = all_results[name]
            writer.writerow(
                {
                    "strategy": name,
                    "selected_split_seed": m["split_seed"],
                    "last_train_loss": m["last_train_loss"],
                    "best_train_loss": m["best_train_loss"],
                    "best_train_loss_round": m["best_train_loss_round"],
                    "client_last_eval_loss": m["client_last_eval_loss"],
                    "client_best_eval_loss": m["client_best_eval_loss"],
                    "client_best_eval_loss_round": m["client_best_eval_loss_round"],
                    "client_last_acc": m["client_last_acc"],
                    "client_best_acc": m["client_best_acc"],
                    "client_best_acc_round": m["client_best_acc_round"],
                    "client_mean_acc_30_50": m["client_mean_acc_30_50"],
                    "client_last_f1": m["client_last_f1"],
                    "client_best_f1": m["client_best_f1"],
                    "client_best_f1_round": m["client_best_f1_round"],
                    "client_mean_f1_30_50": m["client_mean_f1_30_50"],
                    "client_train_num_examples_total": m["client_train_num_examples_total"],
                    "client_eval_num_examples_total": m["client_eval_num_examples_total"],
                    "recommended_final_acc": m["client_best_acc"],
                    "recommended_final_f1": m["client_best_f1"],
                }
            )
    return csv_path


def _export_comparison_plots(
    out_dir: Path,
    strategies: list[str],
    all_results: dict[str, dict[str, Any]],
) -> list[Path]:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    out_dir.mkdir(parents=True, exist_ok=True)
    created: list[Path] = []

    def _annotate_bars(ax, bars) -> None:
        ymax = max((bar.get_height() for bar in bars), default=0.0)
        offset = max(0.01, ymax * 0.015)
        for bar in bars:
            height = float(bar.get_height())
            ax.text(
                bar.get_x() + bar.get_width() / 2.0,
                height + offset,
                f"{height:.3f}",
                ha="center",
                va="bottom",
                fontsize=8,
            )

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    metric_specs = [
        ("train_loss_curve", "Train Loss", True, axes[0, 0]),
        ("client_eval_loss_curve", "Client Eval Loss", True, axes[0, 1]),
        ("client_acc_curve", "Client Accuracy", False, axes[1, 0]),
        ("client_f1_curve", "Client Macro F1", False, axes[1, 1]),
    ]
    for key, title, lower_is_better, ax in metric_specs:
        for name in strategies:
            curve = all_results[name][key]
            if curve:
                rounds = [p[0] for p in curve]
                values = [p[1] for p in curve]
                ax.plot(rounds, values, marker="o", markersize=2, linewidth=1.5, label=name)
        ax.set_title(f"{title} by Round")
        ax.set_xlabel("Round")
        ax.set_ylabel(title)
        if lower_is_better:
            ax.set_ylim(bottom=0.0)
        ax.grid(alpha=0.3)
    handles, labels = axes[0, 0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc="upper center", ncol=min(4, len(labels)))
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    curves_path = out_dir / "comparison_curves.png"
    fig.savefig(curves_path, dpi=180)
    plt.close(fig)
    created.append(curves_path)

    fig2, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 5.5))
    x = list(range(len(strategies)))
    width = 0.36
    best_color = "#2f6fed"
    mean_color = "#e76f51"

    best_acc = [all_results[s]["client_best_acc"] for s in strategies]
    best_f1 = [all_results[s]["client_best_f1"] for s in strategies]
    mean_acc_30_50 = [all_results[s]["client_mean_acc_30_50"] for s in strategies]
    mean_f1_30_50 = [all_results[s]["client_mean_f1_30_50"] for s in strategies]

    bars1 = ax1.bar([i - width / 2 for i in x], best_acc, width=width, color=best_color, label="Best Accuracy")
    bars2 = ax1.bar([i + width / 2 for i in x], mean_acc_30_50, width=width, color=mean_color, label="Mean Accuracy, Rounds 30-50")
    ax1.set_title("Accuracy by Method")
    ax1.set_ylabel("Score")
    ax1.set_xticks(x)
    ax1.set_xticklabels(strategies, rotation=30)
    ax1.grid(axis="y", alpha=0.3)
    _annotate_bars(ax1, bars1)
    _annotate_bars(ax1, bars2)
    ax1.legend(loc="lower right")

    bars3 = ax2.bar([i - width / 2 for i in x], best_f1, width=width, color=best_color, label="Best Macro F1")
    bars4 = ax2.bar([i + width / 2 for i in x], mean_f1_30_50, width=width, color=mean_color, label="Mean Macro F1, Rounds 30-50")
    ax2.set_title("Macro F1 by Method")
    ax2.set_ylabel("Score")
    ax2.set_xticks(x)
    ax2.set_xticklabels(strategies, rotation=30)
    ax2.grid(axis="y", alpha=0.3)
    _annotate_bars(ax2, bars3)
    _annotate_bars(ax2, bars4)
    ax2.legend(loc="lower right")

    fig2.tight_layout()
    bars_path = out_dir / "comparison_bar_metrics.png"
    fig2.savefig(bars_path, dpi=180)
    plt.close(fig2)
    created.append(bars_path)

    return created


def _run_one_strategy(
    grid: Grid,
    strategy_name: str,
    num_clients: int,
    num_rounds: int,
    model: NeuralNetwork,
    prepared,
    learning_rate: float,
    local_epochs: int,
    proximal_mu: float,
    context: Context,
    split_seed: int,
) -> dict[str, Any]:
    strategy = _make_strategy(strategy_name, num_clients, context)
    effective_mu = proximal_mu if strategy_name == "fedprox" else 0.0

    start_kwargs: dict[str, Any] = {
        "grid": grid,
        "initial_arrays": ArrayRecord(model.state_dict()),
        "train_config": ConfigRecord(
            {
                "learning-rate": learning_rate,
                "local-epochs": local_epochs,
                "proximal-mu": effective_mu,
                "split-seed": split_seed,
            }
        ),
        "num_rounds": num_rounds,
    }
    if "evaluate_config" in inspect.signature(strategy.start).parameters:
        start_kwargs["evaluate_config"] = ConfigRecord({"split-seed": split_seed})
    result = strategy.start(**start_kwargs)
    client_max_acc, client_max_acc_round = _max_metric_from_round_dict(
        result.evaluate_metrics_clientapp, "acc"
    )
    client_max_f1, client_max_f1_round = _max_metric_from_round_dict(
        result.evaluate_metrics_clientapp, "f1"
    )
    client_mean_acc_30_50 = _mean_metric_from_round_range(
        result.evaluate_metrics_clientapp, "acc", 30, 50
    )
    client_mean_f1_30_50 = _mean_metric_from_round_range(
        result.evaluate_metrics_clientapp, "f1", 30, 50
    )
    client_min_eval_loss, client_min_eval_loss_round = _min_metric_from_round_dict(
        result.evaluate_metrics_clientapp, "loss"
    )
    min_train_loss, min_train_loss_round = _min_metric_from_round_dict(
        result.train_metrics_clientapp, "train_loss"
    )
    client_train_num_examples_total = _sum_metric_from_record_dict(
        result.train_metrics_clientapp, "train-num-examples"
    )
    client_eval_num_examples_total = _sum_metric_from_record_dict(
        result.evaluate_metrics_clientapp, "eval-num-examples"
    )

    return {
        "split_seed": split_seed,
        "last_train_loss": _last_metric_from_round_dict(
            result.train_metrics_clientapp, "train_loss"
        ),
        "best_train_loss": min_train_loss,
        "best_train_loss_round": min_train_loss_round,
        "client_last_eval_loss": _last_metric_from_round_dict(
            result.evaluate_metrics_clientapp, "loss"
        ),
        "client_best_eval_loss": client_min_eval_loss,
        "client_best_eval_loss_round": client_min_eval_loss_round,
        "client_last_acc": _last_metric_from_round_dict(
            result.evaluate_metrics_clientapp, "acc"
        ),
        "client_best_acc": client_max_acc,
        "client_best_acc_round": client_max_acc_round,
        "client_mean_acc_30_50": client_mean_acc_30_50,
        "client_last_f1": _last_metric_from_round_dict(
            result.evaluate_metrics_clientapp, "f1"
        ),
        "client_best_f1": client_max_f1,
        "client_best_f1_round": client_max_f1_round,
        "client_mean_f1_30_50": client_mean_f1_30_50,
        "client_train_num_examples_total": client_train_num_examples_total,
        "client_eval_num_examples_total": client_eval_num_examples_total,
        "train_loss_curve": _metric_curve_from_round_dict(
            result.train_metrics_clientapp, "train_loss"
        ),
        "client_eval_loss_curve": _metric_curve_from_round_dict(
            result.evaluate_metrics_clientapp, "loss"
        ),
        "client_acc_curve": _metric_curve_from_round_dict(
            result.evaluate_metrics_clientapp, "acc"
        ),
        "client_f1_curve": _metric_curve_from_round_dict(
            result.evaluate_metrics_clientapp, "f1"
        ),
    }


@app.main()
def main(grid: Grid, context: Context):
    num_clients = int(context.run_config["num-clients"])
    num_rounds = int(context.run_config["num-server-rounds"])
    local_epochs = int(context.run_config["local-epochs"])
    learning_rate = float(context.run_config["learning-rate"])
    proximal_mu = float(context.run_config["proximal-mu"])
    strategy_name = str(context.run_config["strategy"])
    compare_strategies_raw = str(context.run_config["compare-strategies"])
    output_dir = str(context.run_config["results-dir"])
    save_plots = _as_bool(context.run_config["save-plots"], default=True)
    partition_mode = str(context.run_config["partition-mode"])
    seed = int(context.run_config["seed"])
    torch_seed = int(context.run_config["torch-seed"])
    x_csv = str(context.run_config["x-csv"])
    y_csv = str(context.run_config["y-csv"])

    strategies = (
        _parse_compare_strategies(compare_strategies_raw)
        if compare_strategies_raw.strip()
        else [strategy_name.lower()]
    )

    all_results: dict[str, dict[str, Any]] = {}
    for name in strategies:
        prepared = load_oulad_partitions(
            x_csv=x_csv,
            y_csv=y_csv,
            num_clients=num_clients,
            seed=seed,
            partition_mode=partition_mode,
        )
        _set_torch_seed(torch_seed)
        model = NeuralNetwork(prepared.input_dim, prepared.num_classes)
        print(f"\n=== Running strategy: {name} (seed={seed}) ===")
        all_results[name] = _run_one_strategy(
            grid=grid,
            strategy_name=name,
            num_clients=num_clients,
            num_rounds=num_rounds,
            model=model,
            prepared=prepared,
            learning_rate=learning_rate,
            local_epochs=local_epochs,
            proximal_mu=proximal_mu,
            context=context,
            split_seed=seed,
        )

    print("\n=== Final Comparison ===")
    for name in strategies:
        metrics = all_results[name]
        print(
            f"{name}: "
            f"train_loss(last={metrics['last_train_loss']}, "
            f"best={metrics['best_train_loss']}@r{metrics['best_train_loss_round']}) "
            f"client_acc(last={metrics['client_last_acc']}, "
            f"best={metrics['client_best_acc']}@r{metrics['client_best_acc_round']}, "
            f"mean30_50={metrics['client_mean_acc_30_50']}) "
            f"client_f1(last={metrics['client_last_f1']}, "
            f"best={metrics['client_best_f1']}@r{metrics['client_best_f1_round']}, "
            f"mean30_50={metrics['client_mean_f1_30_50']}) "
            f"client_samples(train_total={metrics['client_train_num_examples_total']}, "
            f"eval_total={metrics['client_eval_num_examples_total']})"
        )

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_config_slug = _run_config_slug(context, strategies)
    out_dir = Path(output_dir) / f"{run_id}__{run_config_slug}"
    csv_path = _export_comparison_csv(out_dir, strategies, all_results)
    print(f"\nSaved comparison CSV: {csv_path}")
    if save_plots:
        try:
            plot_paths = _export_comparison_plots(out_dir, strategies, all_results)
            for p in plot_paths:
                print(f"Saved comparison figure: {p}")
        except Exception as exc:
            print(f"Skipping plot export due to error: {exc}")
