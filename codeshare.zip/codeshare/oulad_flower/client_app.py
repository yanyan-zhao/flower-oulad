from __future__ import annotations

from flwr.app import ArrayRecord, Context, Message, MetricRecord, RecordDict
from flwr.clientapp import ClientApp
import torch

from oulad_flower.task import (
    NeuralNetwork,
    eval_model,
    load_oulad_partitions,
    make_dataloader,
    split_partition_train_eval,
    train_one_client_with_prox,
)


app = ClientApp()


def _cfg_get_float(cfg, key: str, default: float) -> float:
    try:
        return float(cfg[key])
    except Exception:
        return default


def _cfg_get_int(cfg, key: str, default: int) -> int:
    try:
        return int(cfg[key])
    except Exception:
        return default


def _set_torch_seed(seed: int) -> None:
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


@app.train()
def train(msg: Message, context: Context) -> Message:
    arrays = msg.content["arrays"]
    cfg = msg.content["config"]

    x_csv = str(context.run_config["x-csv"])
    y_csv = str(context.run_config["y-csv"])
    num_clients = int(context.run_config["num-clients"])
    partition_mode = str(context.run_config["partition-mode"])
    seed = int(context.run_config["seed"])
    torch_seed = int(context.run_config["torch-seed"])
    dataloader_seed = int(context.run_config["dataloader-seed"])
    batch_size = int(context.run_config["batch-size"])
    client_eval_size = float(context.run_config["client-eval-size"])

    local_epochs = int(cfg["local-epochs"])
    lr = float(cfg["learning-rate"])
    proximal_mu = _cfg_get_float(cfg, "proximal-mu", float(context.run_config["proximal-mu"]))
    split_seed = _cfg_get_int(cfg, "split-seed", seed)

    partition_id = int(context.node_config["partition-id"])
    client_torch_seed = torch_seed + partition_id
    client_dataloader_seed = dataloader_seed + partition_id
    _set_torch_seed(client_torch_seed)

    prepared = load_oulad_partitions(
        x_csv=x_csv,
        y_csv=y_csv,
        num_clients=num_clients,
        seed=split_seed,
        partition_mode=partition_mode,
    )

    Xc, yc = prepared.partitions[partition_id]
    X_train, _, y_train, _ = split_partition_train_eval(
        Xc, yc, eval_size=client_eval_size, seed=seed, partition_id=partition_id
    )
    trainloader = make_dataloader(
        X_train,
        y_train,
        batch_size=batch_size,
        shuffle=True,
        seed=client_dataloader_seed,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = NeuralNetwork(prepared.input_dim, prepared.num_classes)

    model.load_state_dict(arrays.to_torch_state_dict())
    train_loss = train_one_client_with_prox(
        model=model,
        loader=trainloader,
        epochs=local_epochs,
        lr=lr,
        device=device,
        proximal_mu=proximal_mu,
    )

    content = RecordDict(
        {
            "arrays": ArrayRecord(model.state_dict()),
            "metrics": MetricRecord(
                {
                    "train_loss": float(train_loss),
                    "num-examples": len(trainloader.dataset),
                    "train-num-examples": len(trainloader.dataset),
                }
            ),
        }
    )
    return msg.create_reply(content)


@app.evaluate()
def evaluate(msg: Message, context: Context) -> Message:
    arrays = msg.content["arrays"]

    x_csv = str(context.run_config["x-csv"])
    y_csv = str(context.run_config["y-csv"])
    num_clients = int(context.run_config["num-clients"])
    partition_mode = str(context.run_config["partition-mode"])
    seed = int(context.run_config["seed"])
    torch_seed = int(context.run_config["torch-seed"])
    dataloader_seed = int(context.run_config["dataloader-seed"])
    batch_size = int(context.run_config["batch-size"])
    client_eval_size = float(context.run_config["client-eval-size"])
    partition_id = int(context.node_config["partition-id"])
    client_torch_seed = torch_seed + partition_id
    client_dataloader_seed = dataloader_seed + partition_id
    _set_torch_seed(client_torch_seed)
    cfg = msg.content["config"] if "config" in msg.content else {}
    split_seed = _cfg_get_int(cfg, "split-seed", seed)

    prepared = load_oulad_partitions(
        x_csv=x_csv,
        y_csv=y_csv,
        num_clients=num_clients,
        seed=split_seed,
        partition_mode=partition_mode,
    )
    Xc, yc = prepared.partitions[partition_id]
    _, X_eval, _, y_eval = split_partition_train_eval(
        Xc, yc, eval_size=client_eval_size, seed=seed, partition_id=partition_id
    )
    evalloader = make_dataloader(
        X_eval,
        y_eval,
        batch_size=batch_size,
        shuffle=False,
        seed=client_dataloader_seed,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = NeuralNetwork(prepared.input_dim, prepared.num_classes)
    model.load_state_dict(arrays.to_torch_state_dict())
    metrics = eval_model(model, evalloader, device)

    content = RecordDict(
        {
            "metrics": MetricRecord(
                {
                    "loss": float(metrics["loss"]),
                    "acc": float(metrics["acc"]),
                    "f1": float(metrics["f1"]),
                    "num-examples": len(evalloader.dataset),
                    "eval-num-examples": len(evalloader.dataset),
                }
            )
        }
    )
    return msg.create_reply(content)
