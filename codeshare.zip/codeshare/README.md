# Reproducibility Package: Federated Learning Strategies for OULAD

This package contains the source code used to compare federated-learning
strategies for OULAD student-outcome prediction. The implementation uses
Flower 1.26.1 and PyTorch.

## Contents

- `oulad_flower/`: Flower `ClientApp`, `ServerApp`, data utilities, and model.
- `pyproject.toml`: Python dependencies, Flower entry points, and the default
  experiment configuration.
- `data/`: instructions for supplying the preprocessed OULAD feature and
  label CSV files. The source OULAD data are not redistributed here.

## Software requirements

- Python 3.10 or later (the original experiments used Python 3.11).
- A CPU or GPU environment supported by PyTorch.

Create and activate a clean Python environment, then install the application:

```bash
python -m pip install --upgrade pip
python -m pip install .
```

This installs the dependencies declared in `pyproject.toml`, including
`flwr[simulation]==1.26.1`, PyTorch, NumPy, pandas, scikit-learn, and
Matplotlib.

## Data preparation

Download the Open University Learning Analytics Dataset (OULAD) from its
official source and comply with its licence and terms of use. This repository
does not redistribute OULAD or the locally generated CSV files.

The Flower application expects two CSV files:

- a numeric feature matrix (`x-csv`), with one row per student registration;
- an integer label vector (`y-csv`), with the same row order and one target
  label per row.

The feature matrix used by the regional-partition experiment must contain the
13 one-hot region indicators in zero-indexed columns 38--50, because
`partition-mode="region_dummy"` creates one simulated client per region using
these columns. Set `num-clients = 13` for this mode. The manuscript describes
the feature construction, categorical encoding, and outcome definitions.

Place the generated files in the package root or another accessible location,
then set `x-csv` and `y-csv` in `pyproject.toml` or override them through
`--run-config`.

## Run one experiment

From this directory, activate the environment containing Flower and run:

```bash
flwr run . --run-config "strategy='fedavg' x-csv='./oulad_pass_fail_x.csv' y-csv='./oulad_pass_fail_y.csv' results-dir='./results_pass_fail'"
```

To compare the seven methods used in the manuscript in one run:

```bash
flwr run . --run-config "compare-strategies='fedavg,fedavgm,fedprox,fedadagrad,fedadam,fedyogi,fedmedian' x-csv='./oulad_pass_fail_x.csv' y-csv='./oulad_pass_fail_y.csv' results-dir='./results_pass_fail'"
```

The default configuration is 50 communication rounds, two local epochs,
batch size 256, local Adam learning rate 0.02, 13 regional clients, and a
20% client-side evaluation split. Strategy-specific settings are recorded in
`pyproject.toml`. Each run writes a timestamped directory under `results-dir`
containing `comparison.csv` and figures.

## Repeat 20 matched seed runs

Use the same seed value for `seed`, `torch-seed`, and `dataloader-seed` for a
matched stochastic condition. The following example runs the Pass/Fail task
for seeds 1--20:

```bash
for seed in $(seq 1 20); do
  flwr run . --run-config "compare-strategies='fedavg,fedavgm,fedprox,fedadagrad,fedadam,fedyogi,fedmedian' seed=${seed} torch-seed=${seed} dataloader-seed=${seed} x-csv='./oulad_pass_fail_x.csv' y-csv='./oulad_pass_fail_y.csv' results-dir='./results_pass_fail'"
done
```

The repeated runs reuse the same underlying OULAD source data. They are
paired stochastic replications under a common experimental protocol, not
independent educational datasets or institutions. Each timestamped result
directory contains `comparison.csv`, including the late-round client-side
mean accuracy and macro-F1 over communication rounds 30--50.

## Scope and limitations

The implementation retains raw client data locally in the simulation, but it
does not implement differential privacy, secure aggregation, or privacy-attack
evaluation. It therefore reduces raw-data sharing but does not provide a
formal privacy guarantee. Client-side evaluation uses held-out subsets within
the regional partitions; it is not an independent external or leave-one-region
out evaluation. Peak metrics are descriptive only. The primary inferential
comparisons use late-round means from communication rounds 30--50.
